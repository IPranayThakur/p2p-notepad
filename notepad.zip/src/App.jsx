/* eslint-disable no-unused-vars */
import { useState, useEffect } from "react";
import Peer from "peerjs";

const App = () => {
  const [peerId, setPeerId] = useState("");
  const [customPeerId, setCustomPeerId] = useState("");
  const [remotePeerId, setRemotePeerId] = useState("");
  const [connection, setConnection] = useState(null);
  const [text, setText] = useState("");
  const [peerInstance, setPeerInstance] = useState(null);
  const [status, setStatus] = useState("Disconnected");

  // List of simple words that can be used as peer IDs
  const simplePeerIds = [
    "tree", "leaf", "book", "desk", "lamp",
    "moon", "star", "sun", "rain", "wind"
  ];

  const initializePeer = (id) => {
    if (peerInstance) {
      peerInstance.disconnect();
    }

    const peer = new Peer(id);
    setPeerInstance(peer);

    peer.on("open", (id) => {
      setPeerId(id);
      setStatus("Connected as: " + id);
      console.log("Your Peer ID:", id);
    });

    peer.on("error", (error) => {
      console.error(error);
      setStatus("Error: " + error.type);
    });

    peer.on("connection", (conn) => {
      handleConnection(conn);
    });
  };

  const handleConnection = (conn) => {
    setConnection(conn);
    setStatus("Connected to peer: " + conn.peer);

    conn.on("data", (data) => {
      setText(data);
    });

    conn.on("close", () => {
      setStatus("Connection closed");
      setConnection(null);
    });
  };

  const connectToPeer = () => {
    if (!peerInstance || !remotePeerId) return;
    
    const conn = peerInstance.connect(remotePeerId);
    setStatus("Connecting to: " + remotePeerId);
    
    conn.on("open", () => {
      handleConnection(conn);
    });
  };

  const handleTextChange = (e) => {
    const newText = e.target.value;
    setText(newText);

    if (connection) {
      connection.send(newText);
    }
  };

  useEffect(() => {
    initializePeer();
    return () => {
      if (peerInstance) peerInstance.disconnect();
    };
  }, []);

  const containerStyle = {
    maxWidth: "800px",
    margin: "20px auto",
    padding: "20px",
    boxShadow: "0 0 10px rgba(0,0,0,0.1)",
    borderRadius: "8px",
  };

  const headerStyle = {
    marginBottom: "20px",
  };

  const inputGroupStyle = {
    marginBottom: "15px",
    display: "flex",
    gap: "10px",
  };

  const selectStyle = {
    padding: "8px",
    borderRadius: "4px",
    border: "1px solid #ccc",
  };

  const buttonStyle = {
    padding: "8px 16px",
    backgroundColor: "#007bff",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  };

  const textareaStyle = {
    width: "100%",
    height: "200px",
    padding: "10px",
    borderRadius: "4px",
    border: "1px solid #ccc",
    marginTop: "10px",
  };

  return (
    <div style={containerStyle}>
      <div style={headerStyle}>
        <h1>Collaborative Notepad</h1>
        <p>Status: {status}</p>
      </div>

      <div style={inputGroupStyle}>
        <select 
          style={selectStyle}
          value={customPeerId}
          onChange={(e) => setCustomPeerId(e.target.value)}
        >
          <option value="">Select a Peer ID</option>
          {simplePeerIds.map(id => (
            <option key={id} value={id}>{id}</option>
          ))}
        </select>
        <button 
          style={buttonStyle}
          onClick={() => initializePeer(customPeerId)}
        >
          Set Peer ID
        </button>
      </div>

      <div style={inputGroupStyle}>
        <input
          style={selectStyle}
          type="text"
          placeholder="Enter Peer ID to connect"
          value={remotePeerId}
          onChange={(e) => setRemotePeerId(e.target.value)}
        />
        <button 
          style={buttonStyle}
          onClick={connectToPeer}
        >
          Connect
        </button>
      </div>

      <textarea
        style={textareaStyle}
        value={text}
        onChange={handleTextChange}
        placeholder="Start typing..."
      />
    </div>
  );
};

export default App;